// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
      apiKey: "AIzaSyDwJgr7hlgkbtl3WzveL2y2XHIM6k5m5Vk",
      authDomain: "whats-app-clone-1801f.firebaseapp.com",
      projectId: "whats-app-clone-1801f",
      storageBucket: "whats-app-clone-1801f.appspot.com",
      messagingSenderId: "584246523027",
      appId: "1:584246523027:web:54cf439f34d5c97bc98966",
      measurementId: "G-57CWCYWQ8H"
    };