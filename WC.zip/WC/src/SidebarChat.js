import React from 'react';
import "./SidebarChat.css";
import {Avatar} from '@material-ui/core';

function SidebarChat() {
    return (
        <React.Fragment>
            <div className="SidebarChat">
            <Avatar src="https://avatars.dicebear.com/4.5/api/male/Niks.svg"/>            
            <div className="SidebarChat__info">
                <h2>Niks</h2>
                <p>Last Read</p>
            </div>
            </div>
        </React.Fragment>
    )
}

export default SidebarChat;
